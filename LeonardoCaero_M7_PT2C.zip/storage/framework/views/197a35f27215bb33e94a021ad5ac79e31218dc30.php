<?php $__env->startSection('title', 'Nou Autor'); ?>

<?php $__env->startSection('stylesheets'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Nou Autor</h1>
<a href="<?php echo e(route('autor_list')); ?>">&laquo; Torna</a>
<div style="margin-top: 20px">
    <form method="POST" action="<?php echo e(route('autor_new')); ?>">
        <?php echo csrf_field(); ?>        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="color: red"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div>
            <label for="nom">Nom</label>
            <input type="text" name="nom" value="<?php echo e(old('nom')); ?>"/>
        </div>
        <div>
            <label for="cognoms">Cognoms</label>
            <input type="text" name="cognoms" value="<?php echo e(old('cognoms')); ?>"/>
        </div>
        <button type="submit">Crear Autor</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M07/UF2/PT2C/resources/views/autor/new.blade.php ENDPATH**/ ?>